# ESTADO — memoria entre sesiones

> Este archivo es la memoria del arnés. El líder lo lee al arrancar (paso 3 del
> protocolo) y lo actualiza al cerrar cada fase. Si está desactualizado, el agente
> repite trabajo o lo pierde.

## Sesión actual
- **Fecha:** _(sin iniciar)_
- **Agente:** _(Claude Code / Codex / dsh)_
- **Modelos activos:** _(ver config/models.yaml)_

## Fase en curso
_Ninguna. El arnés está recién instalado._

Siguiente paso: ejecutar `python3 scripts/health_check.py` y, si sale en verde,
pedir al `planificador` que descomponga la primera petición.

## Fases cerradas
| Fase | Objetivo | Veredicto | Artefactos |
|---|---|---|---|
| — | — | — | — |

## Hallazgos pendientes
> Cosas detectadas de pasada que NO son de la fase actual. Se anotan aquí en lugar
> de ampliar el alcance sobre la marcha.

- _(vacío)_

## Decisiones tomadas
> Decisiones de diseño con su motivo, para no reabrir el debate en cada sesión.

- **Modelos 100 % locales vía Ollama.** Motivo: privacidad y coste cero por token.
- **Revisor separado del implementador.** Motivo: el que escribe el código tiene
  sesgo de confirmación; hace falta una reejecución independiente del criterio.
