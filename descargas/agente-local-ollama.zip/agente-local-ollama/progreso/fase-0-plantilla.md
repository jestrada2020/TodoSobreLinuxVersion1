# Fase <N> — <objetivo en una frase>

- **Subagente:** `<implementador|revisor>`
- **Modelo usado:** `<modelo>` (rol: `<rol>`)
- **Fecha:** `<AAAA-MM-DD HH:MM>`
- **Criterio de aceptación:** `<el comando o comprobación sí/no de esta fase>`

## Qué se hizo
Pasos reales ejecutados, en orden.

## Archivos tocados
| Archivo | Acción |
|---|---|
| | creado / modificado / borrado |

## Comandos ejecutados y salida REAL
```bash
$ <comando>
<salida literal, no la que esperabas>
```

## Resultado del criterio de aceptación
- [ ] Pasa
- [ ] No pasa — motivo:

## Veredicto
> Solo lo rellena el subagente `revisor`.

**APROBADO** / **RECHAZADO**

Si RECHAZADO, qué corregir:
1.
