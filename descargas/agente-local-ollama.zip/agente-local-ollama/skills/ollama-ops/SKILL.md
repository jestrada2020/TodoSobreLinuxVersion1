---
name: ollama-ops
description: Gestiona el servicio Ollama y sus modelos locales - arrancar o parar el servidor, listar, descargar y liberar modelos de memoria, y diagnosticar por qué no responde. Úsala cuando el usuario mencione Ollama, modelos locales, "no responde el modelo", falta de RAM/VRAM, o cuando health_check falle en la comprobación de Ollama.
---

# Skill: ollama-ops

## Cuándo usar esta skill
- `health_check.py` falla en la comprobación de Ollama.
- Hay que instalar, listar o liberar un modelo.
- El modelo va lentísimo o se queda sin memoria.

## Diagnóstico (en este orden, no te saltes pasos)

```bash
# 1. ¿Está el servicio vivo?
curl -s http://localhost:11434/api/version || echo "Ollama NO responde"

# 2. ¿Qué modelos hay instalados de verdad?
ollama list

# 3. ¿Qué hay cargado en memoria ahora mismo?
ollama ps

# 4. ¿Cuánta RAM libre queda?
free -h
```

## Operaciones

```bash
# Arrancar el servidor en primer plano (deja la terminal ocupada)
ollama serve

# Arrancarlo como servicio del sistema (recomendado)
sudo systemctl enable --now ollama
systemctl status ollama --no-pager

# Instalar los modelos declarados en config/models.yaml
ollama pull qwen2.5-coder:7b     # codificador
ollama pull deepseek-r1:7b       # razonador
ollama pull llama3.2:3b          # rapido
ollama pull nomic-embed-text     # embeddings

# Ver la ficha de un modelo (contexto, plantilla, parámetros)
ollama show llama3.2:3b

# Liberar memoria: descarga el modelo de RAM sin borrarlo del disco
curl -s http://localhost:11434/api/generate \
  -d '{"model":"llama3.2:3b","keep_alive":0}'
```

## Reglas
- **Un solo modelo grande a la vez.** Libera antes de cargar otro.
- Antes de un `ollama pull`, comprueba espacio en disco: `df -h ~/.ollama`.
- **Nunca ejecutes `ollama rm`** sin confirmación explícita del usuario: borra el
  modelo del disco y la descarga puede ser de varios GB.
- Si un modelo no cabe en RAM, no insistas: propón la alternativa de
  `config/models.yaml` → `alternativas.poca_ram_4gb`.

## Verificación
La skill ha terminado bien cuando `python3 scripts/health_check.py` sale en verde.
