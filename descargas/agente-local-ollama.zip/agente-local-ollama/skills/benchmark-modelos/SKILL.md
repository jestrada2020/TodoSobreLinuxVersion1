---
name: benchmark-modelos
description: Mide latencia, tokens por segundo y calidad de respuesta de los modelos locales instalados para decidir con datos qué modelo asignar a cada rol. Úsala cuando haya que elegir entre varios modelos, cuando el usuario pregunte "cuál es mejor" o "por qué va lento", o antes de fijar valores en config/models.yaml.
---

# Skill: benchmark-modelos

## Cuándo usar esta skill
Antes de fijar o cambiar el modelo de un rol en `config/models.yaml`. No decidas
«a ojo» qué modelo es mejor: mídelo en **esta** máquina.

## Procedimiento

1. Lista lo que hay instalado: herramienta MCP `ollama_listar_modelos`.
2. Ejecuta el banco de pruebas:
   ```bash
   ./scripts/bench-modelos.sh llama3.2:3b qwen2.5-coder:7b deepseek-r1:7b
   ```
3. El script mide, por modelo y con tres prompts de dificultad creciente:
   - **latencia total** (s)
   - **tokens/s** de generación
   - **tiempo al primer token** (percepción de rapidez)
4. Evalúa la **calidad** tú mismo con los criterios de abajo. La velocidad sin
   calidad no sirve.
5. Escribe el resultado como artefacto con la skill `generar-artefacto`.
6. Propón al usuario la asignación de roles y **espera confirmación** antes de
   editar `config/models.yaml`.

## Criterios de calidad (0-2 puntos cada uno)

| Criterio | 0 | 1 | 2 |
|---|---|---|---|
| Sigue el formato pedido | lo ignora | parcial | exacto |
| Corrección factual | inventa | dudas | correcto |
| Concisión | divaga | aceptable | al grano |
| Código ejecutable | no corre | corre con arreglos | corre tal cual |

## Cómo interpretar los números
- **< 10 tok/s** → inservible para uso interactivo; úsalo solo en batch.
- **10-30 tok/s** → aceptable para el rol `razonador`.
- **> 30 tok/s** → apto para el rol `rapido`.
- Si el tiempo al primer token supera los 5 s, el modelo no cabe bien en memoria:
  revisa `num_ctx` y la cuantización.

## Regla
Un modelo más grande que no cabe en RAM es **peor** que uno pequeño que sí cabe:
el sistema empieza a usar swap y la latencia se dispara.
