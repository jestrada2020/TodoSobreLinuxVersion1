# Skills del arnés

Una **skill** es una capacidad empaquetada: instrucciones + scripts + recursos que el
agente carga **solo cuando la tarea lo pide**.

## Formato

Cada skill vive en su propia carpeta con un `SKILL.md` que empieza con frontmatter:

```markdown
---
name: nombre-en-kebab-case
description: Qué hace y CUÁNDO usarla. Este texto es lo único que el agente lee
             para decidir si la carga, así que sé explícito con los disparadores.
---

# Cuerpo: el procedimiento paso a paso.
```

## Regla de oro

**No cargues todas las skills siempre.** Está medido (caso Vercel/v0) que quitar el
80 % de las herramientas de un agente lo hizo 3,5× más rápido, con 37 % menos tokens
y 100 % de tasa de éxito. Cada skill activa compite por el contexto.

El campo `description` es lo que hace que se cargue en el momento justo: escríbelo
pensando en «cuándo», no solo en «qué».

## Skills incluidas

| Skill | Cuándo se activa |
|---|---|
| `ollama-ops` | gestionar el servicio o los modelos de Ollama |
| `benchmark-modelos` | decidir qué modelo usar para un rol, con datos |
| `generar-artefacto` | producir una salida entregable y versionada |
