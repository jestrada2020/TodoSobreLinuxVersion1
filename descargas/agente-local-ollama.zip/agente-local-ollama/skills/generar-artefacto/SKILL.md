---
name: generar-artefacto
description: Produce una salida entregable y versionada en artefactos/ y la registra en artefactos/MANIFEST.json con su hash, fase de origen y modelo usado. Úsala SIEMPRE que el usuario deba conservar un resultado (informe, tabla, gráfico, dataset, script generado), en lugar de dejarlo solo en el chat.
---

# Skill: generar-artefacto

## Qué es un artefacto
Una salida **entregable, versionada y trazable**. Si el usuario va a querer volver a
ese resultado mañana, es un artefacto y va a disco. Si es una respuesta de paso, no
lo es y se queda en la conversación.

## Reglas de oro
1. Un artefacto **nunca** existe sin su entrada en `artefactos/MANIFEST.json`.
2. Nombre: `<tipo>-<tema>-<AAAAMMDD>.<ext>`, en kebab-case, sin espacios ni acentos.
3. Es **inmutable**: no se edita. Si cambia, se crea `-v2` y se marca el anterior
   como `sustituido_por`.
4. Debe llevar cabecera de procedencia: qué modelo lo generó, qué fase y cuándo. Un
   artefacto sin procedencia no es verificable.

## Procedimiento

```bash
# 1. Copia la plantilla adecuada
cp artefactos/plantillas/informe.md artefactos/informe-ia-educacion-20260910.md

# 2. Rellena el contenido y la cabecera de procedencia

# 3. Calcula el hash para poder detectar cambios luego
sha256sum artefactos/informe-ia-educacion-20260910.md | cut -c1-16

# 4. Registra la entrada en el manifiesto
```

Entrada en `artefactos/MANIFEST.json`:

```json
{
  "id": "A3",
  "archivo": "informe-ia-educacion-20260910.md",
  "tipo": "informe",
  "fase_origen": "F3",
  "modelo": "deepseek-r1:7b",
  "rol_modelo": "razonador",
  "creado": "2026-09-10T12:00:00",
  "sha256_corto": "a1b2c3d4e5f6a7b8",
  "entradas": ["datos/articulos/*.pdf"],
  "verificado_por": "revisor",
  "sustituido_por": null
}
```

## Verificación
```bash
# Todo archivo de artefactos/ debe estar en el manifiesto y viceversa
./scripts/verificar.sh
```
Si `verificar.sh` reporta un artefacto huérfano, o lo registras o lo borras. No lo
dejes a medias.
