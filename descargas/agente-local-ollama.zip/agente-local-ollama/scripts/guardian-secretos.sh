#!/usr/bin/env bash
# Hook PreToolUse: impide que el agente exponga secretos.
# Bloquea (exit 2) si detecta lectura de .env o claves en el repositorio.
set -uo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ" || exit 0

# Claude Code pasa el contexto del hook por stdin como JSON. Si no hay stdin,
# el script funciona igual como verificación manual.
ENTRADA=""
if [ ! -t 0 ]; then ENTRADA="$(cat 2>/dev/null || true)"; fi

# 1. Bloquear cualquier intento de tocar .env o claves privadas
if printf '%s' "$ENTRADA" | grep -qE '\.env([^.a-zA-Z]|$)|id_rsa|\.pem|\.ssh/'; then
  echo "BLOQUEADO: el arnés prohíbe leer .env, claves SSH o certificados." >&2
  echo "Usa .env.example para saber qué variables existen." >&2
  exit 2
fi

# 2. Escanear el repositorio en busca de secretos ya escritos
HALLAZGOS="$(grep -rIlE \
  'sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{20,}|(API|SECRET|TOKEN)_KEY[[:space:]]*[:=][[:space:]]*["'"'"'][^"'"'"']{12,}' \
  . \
  --exclude-dir=.git --exclude-dir=__pycache__ --exclude-dir=.venv \
  --exclude-dir=node_modules \
  --exclude='.env' --exclude='guardian-secretos.sh' --exclude='health_check.py' \
  2>/dev/null || true)"

if [ -n "$HALLAZGOS" ]; then
  echo "BLOQUEADO: hay secretos en texto plano en el repositorio:" >&2
  printf '%s\n' "$HALLAZGOS" >&2
  echo "Muévelos a .env antes de continuar." >&2
  exit 2
fi

# 3. .env debe estar ignorado por git
if [ -f .env ] && [ -f .gitignore ] && ! grep -q '^\.env$' .gitignore; then
  echo "BLOQUEADO: .env existe pero no está en .gitignore." >&2
  exit 2
fi

exit 0
