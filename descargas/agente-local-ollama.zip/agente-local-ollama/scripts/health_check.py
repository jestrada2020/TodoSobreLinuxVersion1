#!/usr/bin/env python3
"""Chequeo de salud del arnés. Se ejecuta ANTES de cualquier tarea.

Verifica cuatro cosas:
  1. La estructura de archivos obligatoria existe.
  2. Los JSON son válidos.
  3. No hay secretos expuestos.
  4. Ollama responde y los modelos declarados están instalados.

Código de salida: 0 = verde, 1 = hay fallos que bloquean el trabajo.
Uso:  python3 scripts/health_check.py [--sin-ollama]
"""

import json
import os
import re
import sys
import urllib.error
import urllib.request

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VERDE, ROJO, AMAR, FIN = "\033[92m", "\033[91m", "\033[93m", "\033[0m"

fallos = []
avisos = []


def ok(msg):
    print("  %s✓%s %s" % (VERDE, FIN, msg))


def error(msg):
    print("  %s✗%s %s" % (ROJO, FIN, msg))
    fallos.append(msg)


def aviso(msg):
    print("  %s!%s %s" % (AMAR, FIN, msg))
    avisos.append(msg)


def seccion(titulo):
    print("\n%s" % titulo)


# --------------------------------------------------------------- 1. estructura
OBLIGATORIOS = [
    "AGENTS.md",
    "CLAUDE.md",
    "feature-list.json",
    ".mcp.json",
    "config/models.yaml",
    "config/settings.json",
    "agents/planificador.md",
    "agents/implementador.md",
    "agents/revisor.md",
    "mcp/ollama_mcp_server.py",
    "artefactos/MANIFEST.json",
    "progreso/ESTADO.md",
]


def comprobar_estructura():
    seccion("1. Estructura de archivos")
    for rel in OBLIGATORIOS:
        if os.path.exists(os.path.join(RAIZ, rel)):
            ok(rel)
        else:
            error("falta %s" % rel)


# -------------------------------------------------------------------- 2. JSON
def comprobar_json():
    seccion("2. Validez de los JSON")
    for rel in ("feature-list.json", ".mcp.json", "config/settings.json",
                "artefactos/MANIFEST.json"):
        ruta = os.path.join(RAIZ, rel)
        if not os.path.exists(ruta):
            continue
        try:
            with open(ruta, encoding="utf-8") as fh:
                json.load(fh)
            ok("%s es JSON válido" % rel)
        except json.JSONDecodeError as exc:
            error("%s tiene JSON inválido: línea %d" % (rel, exc.lineno))


# ----------------------------------------------------------------- 3. secretos
PATRONES = [
    (r"sk-[A-Za-z0-9]{20,}", "clave tipo sk-..."),
    (r"(?i)api[_-]?key\s*[:=]\s*['\"][^'\"]{12,}", "api_key con valor literal"),
    (r"ghp_[A-Za-z0-9]{20,}", "token de GitHub"),
]
SALTAR = {".git", "__pycache__", ".venv", "node_modules"}


def comprobar_secretos():
    seccion("3. Secretos expuestos")
    encontrados = 0
    for base, dirs, files in os.walk(RAIZ):
        dirs[:] = [d for d in dirs if d not in SALTAR]
        for nombre in files:
            if nombre in (".env", "health_check.py", "guardian-secretos.sh"):
                continue
            if not nombre.endswith((".md", ".json", ".yaml", ".yml", ".sh", ".py", ".txt")):
                continue
            ruta = os.path.join(base, nombre)
            try:
                with open(ruta, encoding="utf-8", errors="ignore") as fh:
                    texto = fh.read()
            except OSError:
                continue
            for patron, etiqueta in PATRONES:
                if re.search(patron, texto):
                    error("%s: posible %s" % (os.path.relpath(ruta, RAIZ), etiqueta))
                    encontrados += 1
    if not encontrados:
        ok("no se detectaron secretos en el repositorio")
    if os.path.exists(os.path.join(RAIZ, ".env")):
        gi = os.path.join(RAIZ, ".gitignore")
        contenido = open(gi, encoding="utf-8").read() if os.path.exists(gi) else ""
        if ".env" in contenido:
            ok(".env existe y está en .gitignore")
        else:
            error(".env existe pero NO está en .gitignore")


# ------------------------------------------------------------------ 4. Ollama
def leer_modelos_declarados():
    """Extrae los valores de 'modelo:' de config/models.yaml sin dependencias."""
    ruta = os.path.join(RAIZ, "config", "models.yaml")
    if not os.path.exists(ruta):
        return []
    declarados = []
    dentro_roles = False
    for linea in open(ruta, encoding="utf-8"):
        limpia = linea.rstrip("\n")
        if re.match(r"^roles:\s*$", limpia):
            dentro_roles = True
            continue
        if re.match(r"^[a-z_]+:\s*$", limpia) and not limpia.startswith(" "):
            dentro_roles = limpia.startswith("roles")
        if dentro_roles:
            m = re.match(r"^\s+modelo:\s*(\S+)", limpia)
            if m:
                declarados.append(m.group(1))
    return declarados


def comprobar_ollama():
    seccion("4. Ollama y modelos locales")
    host = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
    try:
        with urllib.request.urlopen(host + "/api/tags", timeout=10) as resp:
            datos = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, OSError) as exc:
        error("Ollama no responde en %s (%s). Arráncalo: sudo systemctl start ollama"
              % (host, getattr(exc, "reason", exc)))
        return
    ok("Ollama responde en %s" % host)

    instalados = {m.get("name", "") for m in datos.get("models", [])}
    instalados_base = {n.split(":")[0] for n in instalados}
    if not instalados:
        error("no hay ningún modelo instalado (ollama pull llama3.2:3b)")
        return
    ok("%d modelo(s) instalado(s)" % len(instalados))

    for declarado in leer_modelos_declarados():
        if declarado in instalados or declarado.split(":")[0] in instalados_base:
            ok("modelo declarado disponible: %s" % declarado)
        else:
            aviso("declarado en models.yaml pero NO instalado: %s "
                  "(ollama pull %s)" % (declarado, declarado))


def main():
    print("=" * 62)
    print(" CHEQUEO DE SALUD DEL ARNÉS")
    print(" raíz: %s" % RAIZ)
    print("=" * 62)

    comprobar_estructura()
    comprobar_json()
    comprobar_secretos()
    if "--sin-ollama" in sys.argv:
        seccion("4. Ollama y modelos locales")
        aviso("omitido por --sin-ollama")
    else:
        comprobar_ollama()

    print("\n" + "=" * 62)
    if fallos:
        print("%sROJO: %d fallo(s) bloqueante(s).%s No empieces a trabajar."
              % (ROJO, len(fallos), FIN))
        for f in fallos:
            print("   - %s" % f)
        print("=" * 62)
        return 1
    if avisos:
        print("%sVERDE con %d aviso(s).%s Puedes trabajar, revisa los avisos."
              % (AMAR, len(avisos), FIN))
        print("=" * 62)
        return 0
    print("%sVERDE: todo correcto. El arnés está listo.%s" % (VERDE, FIN))
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
