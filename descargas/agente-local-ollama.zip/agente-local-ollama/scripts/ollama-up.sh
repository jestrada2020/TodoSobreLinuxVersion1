#!/usr/bin/env bash
# Utilidad de ciclo de vida de Ollama y sus modelos.
# Uso: ./scripts/ollama-up.sh {start|stop|status|pull|free}
set -uo pipefail
HOST="${OLLAMA_HOST:-http://localhost:11434}"
ACCION="${1:-status}"

case "$ACCION" in
  start)
    if curl -sf "$HOST/api/version" >/dev/null 2>&1; then
      echo "Ollama ya está en marcha en $HOST"
    elif command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files 2>/dev/null | grep -q '^ollama'; then
      sudo systemctl start ollama && echo "Servicio ollama arrancado"
    else
      echo "Arrancando 'ollama serve' en segundo plano (log: /tmp/ollama.log)"
      nohup ollama serve >/tmp/ollama.log 2>&1 &
      sleep 3
    fi
    curl -sf "$HOST/api/version" >/dev/null 2>&1 && echo "OK: Ollama responde" || { echo "ERROR: no responde"; exit 1; }
    ;;
  stop)
    if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet ollama; then
      sudo systemctl stop ollama && echo "Servicio ollama detenido"
    else
      pkill -f 'ollama serve' && echo "Proceso 'ollama serve' detenido" || echo "No había proceso que detener"
    fi
    ;;
  status)
    echo "== Servicio =="
    curl -sf "$HOST/api/version" 2>/dev/null || echo "Ollama NO responde en $HOST"
    echo; echo "== Modelos instalados =="
    ollama list 2>/dev/null || echo "(comando ollama no disponible)"
    echo; echo "== Cargados en memoria =="
    ollama ps 2>/dev/null || true
    echo; echo "== Memoria del sistema =="
    free -h 2>/dev/null | head -2
    ;;
  pull)
    # Instala los modelos declarados en config/models.yaml
    RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    MODELOS="$(grep -oP '^\s+modelo:\s*\K\S+' "$RAIZ/config/models.yaml" | sort -u)"
    [ -z "$MODELOS" ] && { echo "No hay modelos declarados en config/models.yaml"; exit 1; }
    echo "Se van a descargar estos modelos:"; printf '  - %s\n' $MODELOS
    read -r -p "¿Continuar? Puede ser varios GB [s/N] " R
    [ "$R" = "s" ] || [ "$R" = "S" ] || { echo "Cancelado"; exit 0; }
    for m in $MODELOS; do echo ">> ollama pull $m"; ollama pull "$m"; done
    ;;
  free)
    # Descarga los modelos de RAM sin borrarlos del disco
    for m in $(ollama ps 2>/dev/null | awk 'NR>1{print $1}'); do
      echo "Liberando $m de memoria"
      curl -s "$HOST/api/generate" -d "{\"model\":\"$m\",\"keep_alive\":0}" >/dev/null
    done
    echo "Memoria liberada"; ollama ps 2>/dev/null || true
    ;;
  *)
    echo "Uso: $0 {start|stop|status|pull|free}"; exit 1 ;;
esac
