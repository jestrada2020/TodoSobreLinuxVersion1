#!/usr/bin/env bash
# Verificación de coherencia del arnés. Sale 0 (verde) o 1 (rojo).
# Se ejecuta al cerrar cada fase y lo reejecuta el revisor.
set -uo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ" || exit 1
V=$'\033[92m'; R=$'\033[91m'; F=$'\033[0m'
fallos=0
ok()  { printf '  %s✓%s %s\n' "$V" "$F" "$1"; }
mal() { printf '  %s✗%s %s\n' "$R" "$F" "$1"; fallos=$((fallos+1)); }

echo "== Verificación del arnés =="

# 1. Artefactos y manifiesto deben cuadrar en ambos sentidos
if [ -f artefactos/MANIFEST.json ]; then
  for f in artefactos/*; do
    [ -f "$f" ] || continue
    base="$(basename "$f")"
    [ "$base" = "MANIFEST.json" ] && continue
    if grep -q "\"$base\"" artefactos/MANIFEST.json; then
      ok "artefacto registrado: $base"
    else
      mal "artefacto HUÉRFANO (sin entrada en MANIFEST.json): $base"
    fi
  done
  # Al revés: entradas del manifiesto que ya no existen en disco
  while IFS= read -r nombre; do
    [ -z "$nombre" ] && continue
    if [ ! -f "artefactos/$nombre" ]; then
      mal "MANIFEST.json referencia un archivo inexistente: $nombre"
    fi
  done < <(grep -oP '"archivo"\s*:\s*"\K[^"]+' artefactos/MANIFEST.json 2>/dev/null)
else
  mal "falta artefactos/MANIFEST.json"
fi

# 2. Fases: cada informe de implementador necesita el del revisor
for imp in progreso/fase-*-implementador.md; do
  [ -f "$imp" ] || continue
  rev="${imp/-implementador.md/-revisor.md}"
  if [ -f "$rev" ]; then
    if grep -qiE '^\s*(veredicto\s*:?\s*)?\*{0,2}(APROBADO|RECHAZADO)' "$rev"; then
      ok "fase con veredicto: $(basename "$rev")"
    else
      mal "$(basename "$rev") no declara APROBADO ni RECHAZADO"
    fi
  else
    mal "$(basename "$imp") no tiene informe de revisor: la fase NO está cerrada"
  fi
done

# 3. Los subagentes deben tener frontmatter con name y description
for a in agents/*.md; do
  [ -f "$a" ] || continue
  if head -1 "$a" | grep -q '^---$' && grep -qm1 '^name:' "$a" && grep -qm1 '^description:' "$a"; then
    ok "subagente válido: $(basename "$a")"
  else
    mal "subagente sin frontmatter name/description: $(basename "$a")"
  fi
done

# 4. Lo mismo para las skills
for s in skills/*/SKILL.md; do
  [ -f "$s" ] || continue
  if head -1 "$s" | grep -q '^---$' && grep -qm1 '^name:' "$s" && grep -qm1 '^description:' "$s"; then
    ok "skill válida: $(basename "$(dirname "$s")")"
  else
    mal "skill sin frontmatter name/description: $(dirname "$s")"
  fi
done

# 5. El JSON debe seguir siendo parseable
for j in feature-list.json .mcp.json config/settings.json artefactos/MANIFEST.json; do
  [ -f "$j" ] || continue
  if python3 -c "import json,sys; json.load(open('$j'))" 2>/dev/null; then
    ok "JSON válido: $j"
  else
    mal "JSON inválido: $j"
  fi
done

echo
if [ "$fallos" -eq 0 ]; then
  printf '%sVERDE: verificación superada.%s\n' "$V" "$F"; exit 0
fi
printf '%sROJO: %d fallo(s). La fase NO está terminada.%s\n' "$R" "$fallos" "$F"; exit 1
