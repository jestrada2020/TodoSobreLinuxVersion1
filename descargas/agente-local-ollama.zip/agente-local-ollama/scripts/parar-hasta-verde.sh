#!/usr/bin/env bash
# Hook PostToolUse: "parar hasta verde".
#
# El fallo más caro de un agente es equivocarse en la fase 1 y seguir adelante:
# el error se arrastra hasta el final. Este hook corta ese arrastre.
#
# Salida 2 = bloquea y devuelve el control al agente con el motivo.
set -uo pipefail
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ" || exit 0

if ! ./scripts/verificar.sh >/tmp/arnes-verificar.log 2>&1; then
  echo "PARADA: la verificación está en ROJO. No avances de fase." >&2
  echo "--- salida de verificar.sh ---" >&2
  tail -25 /tmp/arnes-verificar.log >&2
  echo "Corrige lo anterior y vuelve a intentarlo." >&2
  exit 2
fi
exit 0
