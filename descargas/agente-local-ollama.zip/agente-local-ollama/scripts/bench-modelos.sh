#!/usr/bin/env bash
# Banco de pruebas de modelos locales: latencia, tokens/s y tiempo al primer token.
# Uso: ./scripts/bench-modelos.sh modelo1 [modelo2 ...]
# Si no pasas modelos, usa los declarados en config/models.yaml.
set -uo pipefail
HOST="${OLLAMA_HOST:-http://localhost:11434}"
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! curl -sf "$HOST/api/version" >/dev/null 2>&1; then
  echo "ERROR: Ollama no responde en $HOST. Ejecuta: ./scripts/ollama-up.sh start"; exit 1
fi

MODELOS=("$@")
if [ ${#MODELOS[@]} -eq 0 ]; then
  mapfile -t MODELOS < <(grep -oP '^\s+modelo:\s*\K\S+' "$RAIZ/config/models.yaml" | sort -u)
fi
[ ${#MODELOS[@]} -eq 0 ] && { echo "No hay modelos que probar"; exit 1; }

# Tres prompts de dificultad creciente
P1="Responde solo con la palabra: OK"
P2="Resume en exactamente una frase que es el kernel de Linux."
P3="Escribe una funcion Python que reciba una lista de numeros y devuelva la mediana. Solo el codigo, sin explicacion."

printf '%-26s %-8s %8s %8s %8s\n' "MODELO" "PROMPT" "TOTAL_s" "TOK" "TOK/s"
printf '%s\n' "--------------------------------------------------------------------"

for m in "${MODELOS[@]}"; do
  i=0
  for p in "$P1" "$P2" "$P3"; do
    i=$((i+1))
    PAYLOAD="$(python3 -c '
import json,sys
print(json.dumps({"model":sys.argv[1],"prompt":sys.argv[2],"stream":False,
                  "options":{"temperature":0.1}}))' "$m" "$p")"
    RESP="$(curl -s --max-time 300 "$HOST/api/generate" -d "$PAYLOAD" 2>/dev/null)"
    if [ -z "$RESP" ]; then
      printf '%-26s %-8s %8s %8s %8s\n' "$m" "P$i" "ERROR" "-" "-"; continue
    fi
    printf '%s' "$RESP" | python3 -c '
import json, sys
m, i = sys.argv[1], sys.argv[2]
try:
    d = json.load(sys.stdin)
except Exception:
    print("%-26s %-8s %8s %8s %8s" % (m, "P"+i, "ERROR", "-", "-")); sys.exit(0)
tot = d.get("total_duration", 0) / 1e9
n = d.get("eval_count", 0)
ev = d.get("eval_duration", 0) / 1e9
tps = (n / ev) if ev else 0
print("%-26s %-8s %8.2f %8d %8.1f" % (m, "P" + i, tot, n, tps))
' "$m" "$i"
  done
  # Libera el modelo antes de probar el siguiente: evita competir por RAM
  curl -s "$HOST/api/generate" -d "{\"model\":\"$m\",\"keep_alive\":0}" >/dev/null 2>&1
done

echo
echo "Guía: <10 tok/s inservible interactivo | 10-30 apto razonador | >30 apto rapido"
echo "Evalúa la CALIDAD a mano con la tabla de skills/benchmark-modelos/SKILL.md"
