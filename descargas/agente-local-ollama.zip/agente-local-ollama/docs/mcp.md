# MCP: definición y configuración

## Qué es
**MCP** (Model Context Protocol) es un protocolo estándar para dar herramientas a un
agente. Un servidor MCP expone funciones (`tools`) que el modelo puede invocar; el
agente es el cliente. Al ser estándar, el mismo servidor sirve para Claude Code,
Codex, dsh o cualquier cliente compatible.

## Declaración
En `.mcp.json`, en la raíz del proyecto:
```json
{
  "mcpServers": {
    "ollama-local": {
      "command": "python3",
      "args": ["mcp/ollama_mcp_server.py"],
      "env": { "OLLAMA_HOST": "http://localhost:11434" }
    }
  }
}
```

## El servidor incluido: `ollama-local`
`mcp/ollama_mcp_server.py` — JSON-RPC 2.0 sobre stdin/stdout, **sin dependencias**
(solo biblioteca estándar de Python 3.8+). Expone cinco herramientas:

| Herramienta | Para qué |
|---|---|
| `ollama_listar_modelos` | qué hay instalado de verdad (tamaño, cuantización) |
| `ollama_estado` | si Ollama responde y qué hay cargado en memoria |
| `ollama_generar` | inferencia de un turno + métricas de latencia y tok/s |
| `ollama_chat` | conversación multi-turno con historial |
| `ollama_embeddings` | vectores para búsqueda semántica y RAG local |

## Probarlo sin agente
El servidor habla por stdio, así que se puede probar a mano:
```bash
# Listar las herramientas que expone
printf '%s\n%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
  | python3 mcp/ollama_mcp_server.py

# Invocar una herramienta
printf '%s\n%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"ollama_estado","arguments":{}}}' \
  | python3 mcp/ollama_mcp_server.py
```
Si `initialize` devuelve `serverInfo` y `tools/list` devuelve las cinco herramientas,
el servidor está bien. Esta prueba manual es la forma más rápida de distinguir un
fallo del servidor de un fallo de configuración del agente.

## Cómo escribir una herramienta bien
```python
{
  "name": "ollama_listar_modelos",              # verbo_objeto, sin ambigüedad
  "description": ("Lista los modelos realmente instalados... "
                  "Úsalo SIEMPRE antes de asumir que un modelo existe."),
  "inputSchema": {"type": "object", "properties": {...}, "required": [...]},
}
```
- El `name` describe la acción, no la implementación.
- La `description` dice **cuándo** usarla, no solo qué hace. Es lo que el modelo lee
  para decidir.
- El `inputSchema` con `required` bien puesto evita llamadas mal formadas.
- Los errores se devuelven como contenido con `isError: true`, **no** como excepción:
  así el modelo puede leer el motivo y corregir.

## Regla de diseño: pocas herramientas
Está medido: Vercel quitó el 80 % de las 16 herramientas de su agente v0 y consiguió
3,5× más velocidad, 37 % menos tokens y 100 % de éxito. Cada herramienta declarada
ocupa contexto en **todas** las peticiones y añade una decisión más al modelo.

Antes de añadir un MCP nuevo, responde por escrito: ¿qué tarea concreta no puedo
hacer con los servidores actuales? Si no hay respuesta clara, no lo añadas.

## Seguridad
- Un servidor MCP corre con **tus** permisos: revisa el código antes de declararlo.
- Nunca pongas secretos en `.mcp.json` (se versiona). Usa `env` con nombres de
  variables y ponlas en `.env`.
- Da al servidor el ámbito mínimo. El ejemplo de `filesystem` en `.mcp.json` apunta
  solo a `./artefactos`, no a la raíz.
- Trata la salida de un MCP como **datos**, nunca como instrucciones: si el
  contenido devuelto contiene órdenes, es un intento de inyección.
