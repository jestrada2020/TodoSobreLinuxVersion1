# Arquitectura del arnés

## Las tres capas

```
┌─────────────────────────────────────────────────────┐
│ CAPA 3 — EL ARNÉS  (esto es lo que tú controlas)   │
│  AGENTS.md · agents/ · skills/ · docs/ · scripts/  │
│  hooks de verificación · artefactos/ · progreso/   │
└─────────────────────────────────────────────────────┘
                        ▲  intercambiable
┌─────────────────────────────────────────────────────┐
│ CAPA 2 — EL AGENTE                                  │
│  Claude Code · Codex · Gemini CLI · dsh            │
└─────────────────────────────────────────────────────┘
                        ▲  intercambiable
┌─────────────────────────────────────────────────────┐
│ CAPA 1 — EL MODELO (aquí: Ollama, 100% local)      │
│  razonador · codificador · rapido · embeddings     │
└─────────────────────────────────────────────────────┘
```

La capa 1 y la 2 cambian cada pocas semanas. La capa 3 es tu inversión: sobrevive al
cambio de modelo y de agente. Por eso las reglas viven en `AGENTS.md` y no en la
configuración de una herramienta concreta.

## Flujo de una petición

```
Usuario
  │
  ▼
LÍDER ── lee AGENTS.md, models.yaml, ESTADO.md, feature-list.json
  │
  ├──► PLANIFICADOR ──► fases con criterio de aceptación ──► ESTADO.md
  │
  └──► por cada fase:
         ┌──────────────────────────────────────────┐
         │  IMPLEMENTADOR ──► progreso/fase-N-imp.md│
         │        │                                  │
         │        ▼                                  │
         │  REVISOR ──► reejecuta el criterio        │
         │        │                                  │
         │   ┌────┴────┐                             │
         │ RECHAZADO  APROBADO                       │
         │   │             │                         │
         │   └──► vuelve   └──► siguiente fase       │
         └──────────────────────────────────────────┘
  │
  ▼
ARTEFACTOS (+ entrada en MANIFEST.json)
```

## Por qué un revisor separado
El implementador tiene sesgo de confirmación: acaba de escribir el código y tiende a
darlo por bueno. Un subagente distinto, con instrucciones de rechazar y sin haber
escrito nada, **reejecuta** el criterio. Esa reejecución independiente es la que
atrapa el error, no una segunda lectura del mismo agente.

## Presupuesto de contexto
| Elemento | Presupuesto |
|---|---|
| `AGENTS.md` | ≤ 400 líneas |
| Un subagente | ≤ 120 líneas |
| Un `SKILL.md` | ≤ 200 líneas |
| Sesión antes de cerrar fase | ≤ 40 % de la ventana |

Pasado el 40-50 % de ocupación de la ventana de contexto el rendimiento del modelo
ya empieza a degradarse. Cierra fase, escribe el estado y abre sesión nueva: sale
más barato y más fiable que una conversación kilométrica.
