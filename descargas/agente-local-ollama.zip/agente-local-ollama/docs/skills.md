# Skills: definición y configuración

## Qué es
Una capacidad empaquetada que el agente carga **bajo demanda**: instrucciones +
scripts + recursos, en su propia carpeta.

## Anatomía
```
skills/
└── nombre-de-la-skill/
    ├── SKILL.md          # obligatorio: frontmatter + procedimiento
    ├── scripts/          # opcional: ejecutables de apoyo
    └── recursos/         # opcional: plantillas, datos de referencia
```

## El frontmatter
```yaml
---
name: benchmark-modelos
description: Mide latencia y calidad de los modelos locales para decidir qué modelo
             asignar a cada rol. Úsala cuando haya que elegir entre varios modelos
             o antes de fijar valores en config/models.yaml.
---
```

El campo `description` es **lo único** que el agente lee para decidir si carga la
skill. Por eso debe responder a dos preguntas: **qué hace** y, sobre todo, **cuándo
se activa**. Una descripción vaga («utilidades de modelos») nunca se activa en el
momento adecuado.

## Cuerpo del SKILL.md
1. **Cuándo usar esta skill** — disparadores concretos.
2. **Procedimiento** — pasos numerados, con comandos copiables.
3. **Reglas y prohibiciones** — qué no hacer nunca.
4. **Verificación** — cómo saber que la skill terminó bien.

## Carga progresiva
| Nivel | Qué se carga | Coste |
|---|---|---|
| 1 | solo `name` + `description` de cada skill | mínimo, siempre presente |
| 2 | el `SKILL.md` completo | solo si la tarea la dispara |
| 3 | scripts y recursos de la skill | solo al ejecutarlos |

Este escalonado es lo que permite tener muchas skills disponibles sin pagar su
contexto en cada petición.

## Regla de diseño
**Menos es más.** Vercel quitó el 80 % de las 16 herramientas de su agente v0 y
obtuvo 3,5× más velocidad, 37 % menos tokens y 100 % de tasa de éxito. Antes de
crear una skill nueva, pregúntate si no basta con mejorar la descripción de una
existente.

Señales de que una skill está mal diseñada:
- Nunca se activa → la `description` no dice cuándo usarla.
- Se activa siempre → es demasiado genérica; divídela o vuélvela parte de `AGENTS.md`.
- Supera 200 líneas → mueve el detalle a `recursos/` y deja el procedimiento.

## Crear una skill nueva
```bash
mkdir -p skills/mi-skill/{scripts,recursos}
cat > skills/mi-skill/SKILL.md <<'FIN'
---
name: mi-skill
description: Qué hace y cuándo se activa.
---

# Skill: mi-skill

## Cuándo usar esta skill
...
FIN
./scripts/verificar.sh   # valida el frontmatter
```
Después añádela a la tabla de la sección 6 de `AGENTS.md`.
