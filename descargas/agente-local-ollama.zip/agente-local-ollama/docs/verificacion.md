# Verificación: la regla de "parar hasta verde"

## El problema
Un agente que se equivoca en la fase 1 y continúa arrastra el error hasta el final.
El resultado es basura y descubrirlo cuesta más que haberlo parado al principio.

## La regla
**Ninguna fase se cierra sin que la verificación salga en verde.** El avance está
bloqueado por un hook, no por la buena voluntad del modelo.

## Los tres niveles

### 1. Chequeo de salud (antes de empezar)
```bash
python3 scripts/health_check.py
```
Valida estructura, JSON, ausencia de secretos y que Ollama responde con los modelos
declarados. Está enganchado a `SessionStart` en `config/settings.json`.

Salida: `0` verde · `1` rojo bloqueante. Con `--sin-ollama` omite la parte de Ollama
(útil si trabajas sin modelos cargados).

### 2. Verificación de coherencia (al cerrar cada fase)
```bash
./scripts/verificar.sh
```
Comprueba:
- Todo artefacto tiene entrada en `MANIFEST.json` **y** al revés (sin referencias
  a archivos que ya no existen).
- Cada `fase-N-implementador.md` tiene su `fase-N-revisor.md` con veredicto explícito.
- Subagentes y skills con frontmatter válido (`name` + `description`).
- Los JSON siguen siendo parseables.

### 3. Hooks (automáticos, no dependen del modelo)
| Hook | Cuándo | Qué hace |
|---|---|---|
| `guardian-secretos.sh` | `PreToolUse` en Bash | bloquea leer `.env`, claves SSH y secretos en texto plano |
| `parar-hasta-verde.sh` | `PostToolUse` en Write/Edit | si `verificar.sh` falla, bloquea y devuelve el motivo |
| `health_check.py` | `SessionStart` | no deja arrancar con el entorno roto |

Un hook que sale con código **2** bloquea la acción y el motivo vuelve al agente,
que debe corregir. No es un aviso: es una parada.

## Criterio de aceptación
Cada fase de `feature-list.json` necesita un `criterio_aceptacion` que sea **un
comando o comprobación con respuesta sí/no**. Si no se puede comprobar
objetivamente, no es un criterio válido y la fase está mal definida.

Mal: «el informe queda bien».
Bien: «existe `artefactos/informe-X.md`, tiene entrada en `MANIFEST.json` y
`./scripts/verificar.sh` sale en verde».
