# Convenciones

## Nombres
- Archivos y carpetas: `kebab-case`, sin acentos ni espacios.
- Subagentes: `agents/<rol>.md`, el `name:` del frontmatter igual al del archivo.
- Skills: `skills/<nombre>/SKILL.md`.
- Artefactos: `<tipo>-<tema>-<AAAAMMDD>.<ext>`.
- Informes de fase: `progreso/fase-<N>-<subagente>.md`.

## Idioma
Documentación, comentarios y mensajes al usuario en **español**. Los identificadores
de código (variables, funciones) en español también, por coherencia con este arnés.

## Markdown
- Un `# H1` por archivo.
- Bloques de código siempre con lenguaje declarado (```bash, ```python, ```json).
- Los comandos de ejemplo deben ser **copiables y ejecutables** tal cual.

## Frontmatter obligatorio
Subagentes y skills empiezan con:
```yaml
---
name: identificador-kebab-case
description: Qué hace y CUÁNDO usarlo. Es lo único que se lee para decidir cargarlo.
---
```
En subagentes se añade `tools:` (lista mínima necesaria) y `model:` (rol, no nombre
de modelo concreto: así el arnés no se rompe al cambiar de modelo).

## Commits (si usas git)
`<tipo>(<ámbito>): <qué cambió>` — tipos: `feat`, `fix`, `docs`, `chore`, `refactor`.
Ejemplo: `feat(skills): añade benchmark-modelos`.

## Prohibido
- Rutas absolutas de tu máquina en archivos versionados. Usa rutas relativas a la
  raíz del arnés.
- Secretos en cualquier archivo que no sea `.env`.
- Añadir un MCP o una skill sin actualizar `AGENTS.md`.
- Marcar una fase como cerrada sin el informe del revisor.
