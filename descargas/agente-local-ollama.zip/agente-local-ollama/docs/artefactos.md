# Artefactos: definición y configuración

## Qué es un artefacto
Una salida **entregable, versionada y trazable**. Criterio práctico: si el usuario
querrá volver a ese resultado mañana, es un artefacto y va a disco en `artefactos/`.
Si es una respuesta de paso, se queda en la conversación.

Son artefactos: informes, tablas comparativas, gráficos, datasets limpios, scripts
generados, bibliografías, resúmenes ejecutables.

No son artefactos: respuestas conversacionales, logs de depuración, archivos
temporales de trabajo.

## Las cuatro reglas
1. **Sin manifiesto no existe.** Todo artefacto tiene su entrada en
   `artefactos/MANIFEST.json`. `verificar.sh` falla si hay huérfanos en cualquiera
   de los dos sentidos.
2. **Inmutable.** No se edita un artefacto publicado. Si cambia, se crea `-v2` y el
   anterior se marca con `sustituido_por`.
3. **Con procedencia.** Qué modelo lo generó, con qué rol, en qué fase y cuándo. Un
   artefacto sin procedencia no se puede auditar.
4. **Con hash.** `sha256` corto para detectar modificaciones posteriores.

## Esquema del manifiesto
```json
{
  "id": "A1",
  "archivo": "informe-tema-20260910.md",
  "tipo": "informe|tabla|grafico|dataset|script",
  "fase_origen": "F3",
  "modelo": "deepseek-r1:7b",
  "rol_modelo": "razonador",
  "creado": "2026-09-10T12:00:00",
  "sha256_corto": "a1b2c3d4e5f6a7b8",
  "entradas": ["datos/fuente.csv"],
  "verificado_por": "revisor",
  "sustituido_por": null
}
```

`entradas` es lo que hace el artefacto reproducible: dice de qué se generó. Sin ese
campo no puedes rehacerlo ni saber si la fuente cambió.

## Cabecera de procedencia
Todo artefacto en Markdown empieza con:
```markdown
> **Procedencia** — Generado por el arnés `agente-local-ollama`
> · Modelo: `deepseek-r1:7b` (rol: razonador) · Fase: F3
> · Fecha: 2026-09-10 · Entradas: `datos/fuente.csv`
> · Verificado por: subagente `revisor`
```

## Ciclo de vida
```
implementador genera  →  hash + entrada en MANIFEST  →  revisor verifica
        │                                                      │
        │                                              ┌───────┴───────┐
        │                                          APROBADO       RECHAZADO
        │                                              │               │
        └──────────────────────────────────────────────┘         se corrige
                                                                  y repite
```

## Verificación
```bash
./scripts/verificar.sh                    # huérfanos y referencias rotas
sha256sum -c <(...)                       # integridad, si guardas los hashes largos
```
