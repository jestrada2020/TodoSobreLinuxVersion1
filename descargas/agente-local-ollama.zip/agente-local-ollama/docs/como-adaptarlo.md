# Cómo adaptar este arnés a tu proyecto

## Instalación en un proyecto ya en marcha

```bash
# 1. Copia el arnés dentro de tu proyecto
cp -r agente-local-ollama/* ~/mi-proyecto/

# 2. ANTES de ejecutar nada, revisa qué has copiado.
#    Vale para este arnés y para cualquier repo que descargues.
find ~/mi-proyecto -name '*.sh' -o -name '*.py' | xargs -r file
grep -rn 'curl\|wget\|eval\|base64' ~/mi-proyecto/scripts/ || true

# 3. Prepara el entorno
cd ~/mi-proyecto
cp .env.example .env          # y rellena OLLAMA_HOST si no es el de por defecto
./scripts/ollama-up.sh start
./scripts/ollama-up.sh pull   # descarga los modelos de config/models.yaml

# 4. Comprueba que arranca en verde
python3 scripts/health_check.py
./scripts/verificar.sh
```

## Los cinco archivos que SÍ tienes que editar

| Archivo | Qué cambiar |
|---|---|
| `AGENTS.md` | sección 1 (objetivo) y 9 (mapa) para tu proyecto real |
| `config/models.yaml` | los modelos según tu RAM/GPU (mira `alternativas`) |
| `feature-list.json` | sustituye la feature `F3` por tu primera tarea real |
| `docs/convenciones.md` | tus reglas de nombres y estilo |
| `.mcp.json` | añade solo los MCPs que de verdad necesites |

El resto funciona tal cual.

## Ajustar según tu hardware

```bash
free -h                      # RAM disponible
nvidia-smi 2>/dev/null       # ¿hay GPU NVIDIA?
df -h ~/.ollama              # espacio para los modelos
```

- **4-8 GB RAM sin GPU** → usa `alternativas.poca_ram_4gb` de `models.yaml`.
- **16 GB RAM** → los valores por defecto (modelos de 7B).
- **GPU de 16 GB+** → `alternativas.gpu_16gb` (modelos de 14B).

Un modelo que no cabe en RAM es **peor** que uno pequeño que sí cabe: el sistema
tira de swap y la latencia se dispara.

## Usarlo con distintos agentes

| Agente | Qué hacer |
|---|---|
| **Claude Code** | copia `config/settings.json` a `.claude/settings.json` y `agents/*.md` a `.claude/agents/`. Lee `CLAUDE.md` → `AGENTS.md`. |
| **Codex / Gemini CLI** | leen `AGENTS.md` directamente. Los hooks se ejecutan a mano o desde tu Makefile. |
| **dsh (DeepSeek Harness)** | preset *standard*, workspace en la raíz del proyecto, y declara el MCP `ollama-local` en Settings → Models. |

Que las reglas vivan en `AGENTS.md` y no en la configuración de una herramienta es
lo que hace posible este cambio sin reescribir nada.

## Añadir un subagente nuevo
```bash
cat > agents/documentador.md <<'FIN'
---
name: documentador
description: Redacta la documentación de lo implementado. Úsalo tras aprobar una fase
             que añade funcionalidad visible para el usuario.
tools: Read, Write, Grep, Glob
model: rapido
---

# Subagente: documentador
## Rol
...
FIN
./scripts/verificar.sh    # valida el frontmatter
```
Y añádelo a la sección 5 de `AGENTS.md`.

## Qué NO hacer
- Añadir MCPs y skills «por si acaso»: degradan la velocidad y el acierto.
- Quitar los hooks de verificación porque «molestan»: son lo que evita que un error
  temprano se arrastre hasta el final.
- Conversaciones kilométricas: cierra fase, guarda estado y abre sesión nueva.
- Dejar que el implementador se apruebe a sí mismo.
