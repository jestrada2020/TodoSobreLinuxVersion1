#!/usr/bin/env python3
"""Servidor MCP para Ollama local.

Expone el catalogo y la inferencia de Ollama como herramientas MCP.
Habla JSON-RPC 2.0 sobre stdin/stdout, sin dependencias externas:
solo biblioteca estandar de Python 3.8+.

Uso (declarado en .mcp.json):
    python3 mcp/ollama_mcp_server.py

Variables de entorno:
    OLLAMA_HOST     por defecto http://localhost:11434
    OLLAMA_TIMEOUT  segundos, por defecto 300
"""

import json
import os
import sys
import urllib.error
import urllib.request

HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
TIMEOUT = int(os.environ.get("OLLAMA_TIMEOUT", "300"))
PROTOCOL_VERSION = "2024-11-05"

# --------------------------------------------------------------------------
# Cliente HTTP minimo contra la API de Ollama
# --------------------------------------------------------------------------


def _peticion(ruta, payload=None, metodo="POST"):
    url = HOST + ruta
    datos = None
    cabeceras = {"Accept": "application/json"}
    if payload is not None:
        datos = json.dumps(payload).encode("utf-8")
        cabeceras["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=datos, headers=cabeceras, method=metodo)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        cuerpo = exc.read().decode("utf-8", "replace")[:500]
        raise RuntimeError("Ollama devolvio HTTP %s: %s" % (exc.code, cuerpo))
    except urllib.error.URLError as exc:
        raise RuntimeError(
            "No se pudo contactar con Ollama en %s (%s). "
            "Arrancalo con: ollama serve" % (HOST, exc.reason)
        )


# --------------------------------------------------------------------------
# Implementacion de las herramientas
# --------------------------------------------------------------------------


def t_listar_modelos(_args):
    datos = _peticion("/api/tags", metodo="GET")
    modelos = datos.get("models", [])
    if not modelos:
        return "No hay modelos instalados. Instala uno con: ollama pull llama3.2:3b"
    lineas = ["Modelos instalados en %s:" % HOST, ""]
    for m in modelos:
        tam_gb = m.get("size", 0) / (1024 ** 3)
        detalles = m.get("details") or {}
        lineas.append(
            "- %s | %.2f GB | params=%s | quant=%s"
            % (
                m.get("name", "?"),
                tam_gb,
                detalles.get("parameter_size", "?"),
                detalles.get("quantization_level", "?"),
            )
        )
    return "\n".join(lineas)


def t_generar(args):
    modelo = args["modelo"]
    payload = {
        "model": modelo,
        "prompt": args["prompt"],
        "stream": False,
        "options": {
            "temperature": args.get("temperatura", 0.2),
            "num_ctx": args.get("num_ctx", 4096),
        },
    }
    if args.get("sistema"):
        payload["system"] = args["sistema"]
    datos = _peticion("/api/generate", payload)
    respuesta = datos.get("response", "")
    dur_s = datos.get("total_duration", 0) / 1e9
    n_out = datos.get("eval_count", 0)
    tps = (n_out / dur_s) if dur_s else 0
    return "%s\n\n---\n[modelo=%s | %.1fs | %d tokens | %.1f tok/s]" % (
        respuesta,
        modelo,
        dur_s,
        n_out,
        tps,
    )


def t_chat(args):
    payload = {
        "model": args["modelo"],
        "messages": args["mensajes"],
        "stream": False,
        "options": {"temperature": args.get("temperatura", 0.2)},
    }
    datos = _peticion("/api/chat", payload)
    return (datos.get("message") or {}).get("content", "")


def t_embeddings(args):
    payload = {"model": args["modelo"], "prompt": args["texto"]}
    datos = _peticion("/api/embeddings", payload)
    vec = datos.get("embedding", [])
    if not vec:
        return "El modelo no devolvio embeddings. Usa un modelo de embeddings (p.ej. nomic-embed-text)."
    muestra = ", ".join("%.4f" % v for v in vec[:8])
    return "dimensiones=%d\nprimeros_valores=[%s, ...]" % (len(vec), muestra)


def t_estado(_args):
    try:
        cargados = _peticion("/api/ps", metodo="GET").get("models", [])
    except RuntimeError as exc:
        return "Ollama NO responde. %s" % exc
    if not cargados:
        return "Ollama responde en %s. Ningun modelo cargado en memoria ahora." % HOST
    lineas = ["Ollama responde en %s. Modelos en memoria:" % HOST, ""]
    for m in cargados:
        lineas.append(
            "- %s | VRAM/RAM=%.2f GB" % (m.get("name", "?"), m.get("size_vram", 0) / (1024 ** 3))
        )
    return "\n".join(lineas)


HERRAMIENTAS = [
    {
        "name": "ollama_listar_modelos",
        "description": (
            "Lista los modelos realmente instalados en Ollama, con tamano y "
            "cuantizacion. Usalo SIEMPRE antes de asumir que un modelo existe."
        ),
        "inputSchema": {"type": "object", "properties": {}},
        "_fn": t_listar_modelos,
    },
    {
        "name": "ollama_estado",
        "description": (
            "Comprueba que Ollama responde y que modelos estan cargados en memoria. "
            "Usalo para diagnosticar antes de reportar un fallo."
        ),
        "inputSchema": {"type": "object", "properties": {}},
        "_fn": t_estado,
    },
    {
        "name": "ollama_generar",
        "description": (
            "Inferencia local de un solo turno con un modelo de Ollama. Devuelve la "
            "respuesta y metricas (latencia y tokens/s). Para conversacion con "
            "historial usa ollama_chat."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "modelo": {"type": "string", "description": "Nombre exacto, p.ej. llama3.2:3b"},
                "prompt": {"type": "string", "description": "Instruccion para el modelo"},
                "sistema": {"type": "string", "description": "Prompt de sistema (opcional)"},
                "temperatura": {"type": "number", "description": "0.0-1.0, por defecto 0.2"},
                "num_ctx": {"type": "integer", "description": "Ventana de contexto, por defecto 4096"},
            },
            "required": ["modelo", "prompt"],
        },
        "_fn": t_generar,
    },
    {
        "name": "ollama_chat",
        "description": (
            "Conversacion multi-turno con un modelo local. 'mensajes' es una lista de "
            "{role, content} con role en system|user|assistant."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "modelo": {"type": "string"},
                "mensajes": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "role": {"type": "string", "enum": ["system", "user", "assistant"]},
                            "content": {"type": "string"},
                        },
                        "required": ["role", "content"],
                    },
                },
                "temperatura": {"type": "number"},
            },
            "required": ["modelo", "mensajes"],
        },
        "_fn": t_chat,
    },
    {
        "name": "ollama_embeddings",
        "description": (
            "Genera el vector de embeddings de un texto para busqueda semantica o RAG "
            "local. Requiere un modelo de embeddings, no de chat."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "modelo": {"type": "string", "description": "p.ej. nomic-embed-text"},
                "texto": {"type": "string"},
            },
            "required": ["modelo", "texto"],
        },
        "_fn": t_embeddings,
    },
]

POR_NOMBRE = {h["name"]: h for h in HERRAMIENTAS}


# --------------------------------------------------------------------------
# Bucle JSON-RPC sobre stdio
# --------------------------------------------------------------------------


def _resultado(id_, payload):
    return {"jsonrpc": "2.0", "id": id_, "result": payload}


def _error(id_, codigo, mensaje):
    return {"jsonrpc": "2.0", "id": id_, "error": {"code": codigo, "message": mensaje}}


def manejar(mensaje):
    metodo = mensaje.get("method")
    id_ = mensaje.get("id")

    if metodo == "initialize":
        return _resultado(
            id_,
            {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "ollama-local", "version": "1.0.0"},
            },
        )

    if metodo in ("notifications/initialized", "initialized"):
        return None  # las notificaciones no llevan respuesta

    if metodo == "ping":
        return _resultado(id_, {})

    if metodo == "tools/list":
        publicas = [
            {k: v for k, v in h.items() if not k.startswith("_")} for h in HERRAMIENTAS
        ]
        return _resultado(id_, {"tools": publicas})

    if metodo == "tools/call":
        params = mensaje.get("params") or {}
        nombre = params.get("name")
        args = params.get("arguments") or {}
        herramienta = POR_NOMBRE.get(nombre)
        if herramienta is None:
            return _error(id_, -32602, "Herramienta desconocida: %s" % nombre)
        try:
            texto = herramienta["_fn"](args)
            return _resultado(id_, {"content": [{"type": "text", "text": texto}]})
        except KeyError as exc:
            return _resultado(
                id_,
                {
                    "content": [{"type": "text", "text": "Falta el parametro %s" % exc}],
                    "isError": True,
                },
            )
        except Exception as exc:  # noqa: BLE001 - se reporta al cliente MCP
            return _resultado(
                id_,
                {"content": [{"type": "text", "text": "Error: %s" % exc}], "isError": True},
            )

    if id_ is None:
        return None
    return _error(id_, -32601, "Metodo no soportado: %s" % metodo)


def main():
    for linea in sys.stdin:
        linea = linea.strip()
        if not linea:
            continue
        try:
            mensaje = json.loads(linea)
        except json.JSONDecodeError:
            continue
        respuesta = manejar(mensaje)
        if respuesta is not None:
            sys.stdout.write(json.dumps(respuesta) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
