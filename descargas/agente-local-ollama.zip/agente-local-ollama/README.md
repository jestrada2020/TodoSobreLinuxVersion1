# Arnés de agente local con Ollama

Kit para construir un agente de IA **profesional y verificable** que trabaja
**100 % en local** con modelos servidos por Ollama. Incluye subagentes, skills,
artefactos versionados y un servidor MCP funcional.

Parte del curso **Maestría Linux: Deep Dive** (pestaña *Configuración de CLI para IA*).

## Qué trae

| Pieza | Para qué |
|---|---|
| `AGENTS.md` | punto de entrada; reglas, protocolo y mapa del repo |
| `agents/` | 4 subagentes: planificador, implementador, revisor, investigador-local |
| `skills/` | 3 skills: ollama-ops, benchmark-modelos, generar-artefacto |
| `mcp/ollama_mcp_server.py` | servidor MCP con 5 herramientas, sin dependencias |
| `scripts/` | chequeo de salud, verificación y hooks de bloqueo |
| `config/models.yaml` | registro de modelos por rol, con alternativas por hardware |
| `artefactos/` | salidas versionadas + `MANIFEST.json` |
| `docs/` | arquitectura, convenciones, verificación, skills, artefactos, MCP |

## Requisitos

- Linux (o WSL2), Python 3.8+, `curl`
- [Ollama](https://ollama.com) instalado:
  ```bash
  curl -fsSL https://ollama.com/install.sh | sh
  ```
- 8 GB de RAM para los modelos por defecto (hay alternativas para 4 GB)

## Arranque rápido

```bash
# 1. Entra al arnés y prepara el entorno
cd agente-local-ollama
cp .env.example .env

# 2. Arranca Ollama e instala los modelos declarados
./scripts/ollama-up.sh start
./scripts/ollama-up.sh pull

# 3. Comprueba que todo está en verde
python3 scripts/health_check.py

# 4. Prueba el servidor MCP sin necesidad de agente
printf '%s\n%s\n' \
  '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' \
  '{"jsonrpc":"2.0","id":2,"method":"tools/list"}' \
  | python3 mcp/ollama_mcp_server.py
```

Si no tienes aún Ollama en marcha, puedes validar el resto del arnés con:
```bash
python3 scripts/health_check.py --sin-ollama
```

## Conectarlo a tu agente

- **Claude Code** — copia `config/settings.json` a `.claude/settings.json` y
  `agents/*.md` a `.claude/agents/`.
- **Codex / Gemini CLI** — leen `AGENTS.md` directamente.
- **dsh (DeepSeek Harness)** — preset *standard*, workspace en esta carpeta y declara
  el MCP `ollama-local`.

Detalle completo en `docs/como-adaptarlo.md`.

## Cómo funciona

```
LÍDER (lee AGENTS.md)
  └─► PLANIFICADOR ──► fases con criterio de aceptación
        └─► por fase: IMPLEMENTADOR ──► REVISOR ──► ¿aprobado? ──► siguiente
                                            └─► rechazado: vuelve
```

El **revisor** reejecuta el criterio por su cuenta y puede rechazar. El hook
`parar-hasta-verde.sh` impide avanzar mientras la verificación esté en rojo: es lo
que evita que un error de la fase 1 se arrastre hasta el final.

## Principio de diseño: menos es más

Vercel quitó el 80 % de las 16 herramientas de su agente v0 y obtuvo **3,5× más
velocidad, 37 % menos tokens y 100 % de tasa de éxito**. Antes de añadir un MCP o una
skill, justifica por qué no basta con lo que ya hay.

Además, el rendimiento de un modelo empieza a degradarse ya al **40-50 %** de la
ventana de contexto ocupada: cierra fase, guarda estado en `progreso/ESTADO.md` y
abre sesión nueva.

## Seguridad

- `.env` está bloqueado por `guardian-secretos.sh` y excluido en `.gitignore`.
- `config/settings.json` deniega `sudo`, `rm -rf`, `git push`, `ollama rm` y las
  llamadas salientes a APIs de terceros.
- **Revisa los scripts antes de ejecutarlos.** Vale para este kit y para cualquier
  repo que descargues.

## Licencia

MIT. Úsalo y adáptalo libremente.
