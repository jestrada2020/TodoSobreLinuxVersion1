# CLAUDE.md

Este proyecto usa **AGENTS.md** como punto de entrada. Es un estándar abierto.

**Lee `AGENTS.md` y sigue su protocolo antes de hacer cualquier cosa.**

No dupliques instrucciones en este archivo: cualquier regla nueva va en `AGENTS.md`
para que funcione con cualquier agente (Claude Code, Codex, Gemini CLI, dsh).
