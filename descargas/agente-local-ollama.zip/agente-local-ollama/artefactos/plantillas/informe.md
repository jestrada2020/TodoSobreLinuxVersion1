> **Procedencia** — Generado por el arnés `agente-local-ollama`
> · Modelo: `<modelo>` (rol: `<razonador|codificador|rapido>`) · Fase: `<F#>`
> · Fecha: `<AAAA-MM-DD>` · Entradas: `<rutas de los archivos fuente>`
> · Verificado por: subagente `revisor`

# <Título del informe>

## Resumen
Tres o cuatro frases con la conclusión. Quien lea solo esto debe quedarse con lo
importante.

## Método
Qué se hizo, con qué modelo y por qué ese modelo. Si hubo decisiones, cuáles y con
qué criterio.

## Resultados
Datos, tablas o hallazgos. Cada afirmación con su fuente (ruta del archivo).

## Limitaciones
Qué NO cubre este informe y qué quedó sin verificar. Esta sección no es opcional:
un informe sin limitaciones declaradas no es fiable.

## Reproducir
```bash
# Comandos exactos para regenerar este artefacto
```
