> **Procedencia** — Generado por el arnés `agente-local-ollama`
> · Modelo: `<modelo>` (rol: `<rol>`) · Fase: `<F#>`
> · Fecha: `<AAAA-MM-DD>` · Entradas: `<rutas>`
> · Verificado por: subagente `revisor`

# Comparativa: <qué se compara>

## Criterios
| Criterio | Peso | Cómo se mide |
|---|---|---|
| | | |

## Tabla
| Opción | Criterio 1 | Criterio 2 | Criterio 3 | Total |
|---|---|---|---|---|
| | | | | |

## Recomendación
Una opción, con el motivo en una frase. Si no hay ganador claro, dilo explícitamente
en lugar de forzar una recomendación.

## Datos descartados
Qué se midió y no se incluyó, y por qué.
